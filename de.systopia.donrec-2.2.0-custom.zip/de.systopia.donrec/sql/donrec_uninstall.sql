--
-- `donrec_snapshot`
--

DROP TABLE IF EXISTS `donrec_snapshot`;
DROP TABLE IF EXISTS `donrec_profile`;
