# Version History

## Version 1.6
* Select currency (#12)
* Provide "From e-mail" setting in profile (#54)
* "Back" button in Create form does not work (#56)
* "Receipted" search column has no weight (#57)

## Version 1.5
* Sending receipts by email (#40)
* Expose receipt creator (#5)
* First time 'send by email' causes "Mandatory key(s) missing" error (#49)

## Version 1.4
* Compatibility with CiviCRM 4.7 (#34)

## Version 1.3
* Generation Profiles (#30)
* Sequential serial numbers (#1)
* Create receipts from contribution search (#29)

## Version 1.2.1
* "Built-in" localisation (#24)
* Robust SQL escape (#9)
* Fix runner freeze (#28)

## Version 1.2
Initial release
