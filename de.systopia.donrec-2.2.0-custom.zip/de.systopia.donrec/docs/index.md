# Preface

The described software was developed and published in and under legislative
terms of Germany. The said software is an extension for CiviCRM and may be used
to receipt donations according to tax laws. As taxation is specific for certain
countries, the underlying conventions in this extension have to be specific,
too. Great care has to be applied when using the software in other countries. In
order to facilitate the assessment of possibilities and limitations under
foreign tax laws, this documentation is now also given in english.

This CiviCRM extension is licensed under
the [AGPLv3](https://www.gnu.org/licenses/agpl-3.0.html) license.

# Status of this documentation

This documentation is out-of-date as of at least version 1.6 and does not
include changes made in version 2.0 and up, which are quite significant.

If you'd like to contribute to updating this documentation, see
[this issue on GitHub](https://github.com/systopia/de.systopia.donrec/issues/160).

# Acknowledgements

A big thank you to the organisations that funded the initial development of this
extension. These are (in order of contribution):

- muslimehelfen e.V.
- Robin Wood e.V.
- Software für Engagierte e.V.
- Forum Ziviler Friedensdienst e.V.
- ArbeiterKind gUG
- Bergwaldprojekt e.V.
- Digitalcourage e.V.
- Wir sind Kirche e.V.
